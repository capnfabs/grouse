---
title: "Hugo"
draft: false
weight: 3
images: []
borderColor: "cyan"
---

Hugo is a surname and male given name of Germanic origin Hugo, meaning "mind". The English version of the name is Hugh, the Italian version is Ugo. For detailed history and etymology of the name, see Hugh (given name).

Hugo is one of the most popular given names in Europe, ranking as high as #9 in Spain, and #8 in Belgium in 2006. April 1 is the name day of Hugo in many European countries. 