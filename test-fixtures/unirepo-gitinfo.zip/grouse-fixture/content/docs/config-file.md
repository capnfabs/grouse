---
date: 2017-09-25T08:00:00+06:00
lastmod: 2018-02-08T15:15:00+06:00
title: "Configuration File: config.toml"
authors: ["muniftanjim"]
categories:
  - others
tags:
  - config
slug: config-file
---

This is the Minimo's configuration file ( `config.toml` ) file of this site:

{{< file "config.toml" >}}
