# Minimo

Fork of https://github.com/MunifTanjim/minimo, just for testing purposes.

This is just the taxonomy.
