---
title: "Bad Wordsworth"
date: 2019-09-03T23:34:21+02:00
---

> The solitude of glory
> with all the dreary lambs, a thousand valleys of harmony
> for i am lying still, black blisses miles above

-- Courtesy of [Botnik Studios](https://botnik.org/apps/writer/?source=8d6d6722d49fb38ff08016af7a1db7f6)
