---
title: "White-bellied Owlet Nightjar."
date: 2019-09-16T12:17:14+02:00
draft: false
---

This is altogether a larger and more powerful bird than the Ægotheles Novæ-Hollandiæ; besides which, the white colouring of the lower part of the belly will at all times serve to distinguish it from that species.

It is rather abundant on the Cobourg Peninsula, where it inhabits the forests in the immediate vicinity of Port Essington; how far its range may extend is at present unknown, but it is probable that the bird is distributed over the whole of the northern portion of the continent, and that it there forms the representative of the Æ. Novæ-Hollandiæ, which up to the present time has only been found on the southern.

Mr. Gilbert states that it is abundant in most parts of the settlement at Port Essington, “where it is frequently seen flying about at twilight, and occasionally during the day. On the approach of an intruder it flies very heavily from tree to tree, and on alighting invariably turns round on the branch to watch his approach, moving the head all the time after the manner of the Hawk tribe.”

The sexes when fully adult will not I expect be found to differ in plumage. I attribute the redness of some of my specimens to the age of the individuals; but whether the red varieties or the grey are the most mature birds, I have not had sufficient opportunities of ascertaining.

It feeds on insects of all kinds, and as the bird is strictly nocturnal in its habits, they are, as a matter of course, procured at night.

Head black; the crown, a lunar-shaped mark at the back of the head, and a collar surrounding the back of the neck freckled with grey; back freckled black and white; wings brown, crossed by numerous bands of lighter brown freckled with dark brown; primaries margined externally with buff, interrupted with blotchings of dark brown; tail dark brown, crossed by numerous broad irregular bands of reddish buff freckled with dark brown; ear-coverts straw-white; chin, abdomen and under tail-coverts white; breast and sides of the neck white, crossed by numerous freckled bars of black; irides dark brown; upper mandible dark olive-brown, lower mandible white with a black tip; legs very pale yellow; claws black.

The figures are of the natural size.

Source: https://www.gutenberg.org/files/60302/60302-h/60302-h.htm
