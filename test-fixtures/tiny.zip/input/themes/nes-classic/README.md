# hugo-nes-classic
A simple theme using the NES.css framework (https://nostalgic-css.github.io/NES.css/). This is my first Hugo theme. PRs for improvents are welcome! :)
