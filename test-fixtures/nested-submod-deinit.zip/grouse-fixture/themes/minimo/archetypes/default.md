---
date: "{{ .Date }}"
title: "{{ replace .TranslationBaseName '-' ' ' | title }}"
authors: []
categories:
  -
tags:
  -
draft: true
---
